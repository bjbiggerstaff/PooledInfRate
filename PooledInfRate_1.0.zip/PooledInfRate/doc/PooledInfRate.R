## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
x <- c(1,0,0,0)
m <- c(50,25,10,5)

## -----------------------------------------------------------------------------
ex1.dat <- data.frame(Pos = c(1,0,0,0), PoolSize = c(50,25,10,5))
ex1.dat

## -----------------------------------------------------------------------------
ex2.dat <- data.frame(Pos = c(2,1,0,1), 
                      PoolSize = c(50,25,10,5), 
                      NumPools = c(10,10,5,2), 
                      Location = c("A","A","B","B"))
ex2.dat

## -----------------------------------------------------------------------------
mosq.dat <- data.frame(Zone = c(1,1,2,2, 1,1,1,2,2, 1,1,2),
                       Species = rep(c("Culex pipiens","Culex tarsalis", "Culex quinquefaciatus"), 
                                     c(4,5,3)),
                       Pos = c(1,0,0,1, 1,0,1,0,0, 0,1,0),
                       PoolSize = c(100,50,25,5, 200,100,50,25,10, 25,10,5),
                       Nights = c(5,5,3,3,5,5,5,3,3,5,5,3))
mosq.dat

## -----------------------------------------------------------------------------
library(PooledInfRate)

pooledBin(x,m)

with(ex2.dat, pooledBin(Pos, PoolSize, NumPools))

with(mosq.dat, pIR(Pos, PoolSize))

## -----------------------------------------------------------------------------
with(mosq.dat, pooledBin(Pos, PoolSize, group = Species))

## -----------------------------------------------------------------------------
pooledBin(Pos ~ PoolSize, mosq.dat) # the second function argument is data=

## -----------------------------------------------------------------------------
pooledBin(Pos ~ PoolSize | Species, mosq.dat) # the second function argument is data=

## -----------------------------------------------------------------------------
pooledBin(Pos ~ m(PoolSize) + n(NumPools), ex2.dat)

## -----------------------------------------------------------------------------
pooledBin(Pos ~ PoolSize + n(NumPools), ex2.dat)

## -----------------------------------------------------------------------------
pooledBin(Pos ~ m(PoolSize) + n(NumPools), ex2.dat)
pooledBin(Pos ~   PoolSize  + n(NumPools), ex2.dat)
pooledBin(Pos ~ n(NumPools) + m(PoolSize), ex2.dat)
pooledBin(Pos ~ n(NumPools) +   PoolSize , ex2.dat)

## -----------------------------------------------------------------------------
pooledBin(Pos ~ PoolSize + n(NumPools) | Location, ex2.dat)

# and use the (significant) 'digits' argument of print() to make for easier reading
print(pooledBin(Pos ~ PoolSize + n(NumPools) | Location, ex2.dat), digits = 3)

## -----------------------------------------------------------------------------
pir.combined.out <- pIR(Pos ~ PoolSize + n(NumPools), ex2.dat)
summary(pir.combined.out)

pir.location.out <- pIR(Pos ~ PoolSize + n(NumPools) | Location, ex2.dat)
summary(pir.location.out)

pir.mosq.out <- pIR(Pos ~ PoolSize | Species, mosq.dat)
print(summary(pir.mosq.out), digits=3)

## ----fig.cap="Binomial model diagnostic plot of Chen and Swallow (1990)"------
plot(pir.combined.out)

## -----------------------------------------------------------------------------
x.na <- c(1,0,0,NA,1)
m.na <- c(10,50,25,10,10)

pooledBin(x.na, m.na)

summary(pooledBin(x.na,m.na))

## -----------------------------------------------------------------------------
pIR(Pos ~ PoolSize, mosq.dat, pt.method = "firth", ci.method = "skew-score") # the defaults 
pIR(Pos ~ PoolSize, mosq.dat, pt.method = "gart", ci.method = "score") 
pIR(Pos ~ PoolSize, mosq.dat, pt.method = "mle", ci.method = "wald") 
# specification of "mir" for either sets the other to "mir"
pIR(Pos ~ PoolSize, mosq.dat, pt.method = "mir", ci.method = "mir") 

## -----------------------------------------------------------------------------
pIR(Pos ~ PoolSize, mosq.dat) # default scale = 1
pIR(Pos ~ PoolSize, mosq.dat, scale=1000)

## -----------------------------------------------------------------------------
x1 <- c(1,0,0,0)
m1 <- c(100,50,25,10)
x2 <- c(1,1,0,0)
m2 <- c(50,40,30,20)
pooledBinDiff(x1,m1,x2,m2)

n1 <- c(10,20,30,40)
n2 <- rep(1,4)
pooledBinDiff(x1,m1,x2,m2,n1,n2)

pooledBinDiff(Pos ~ PoolSize + n(NumPools) | Location, ex2.dat)

mdiff.out <- pIRDiff(Pos ~ PoolSize | Species, mosq.dat, scale=1000) # scale for easier interpretation

## Print fewer digits for easier reading 
print(summary(mdiff.out), digits = 3) 

## -----------------------------------------------------------------------------
vi.out <- with(mosq.dat, vectorIndex(Pos,PoolSize,vector=Species)) # or use VI()
vi.out

## -----------------------------------------------------------------------------
summary(vi.out)

## -----------------------------------------------------------------------------
vectorIndex(Pos ~ PoolSize / Species, mosq.dat)

## -----------------------------------------------------------------------------
with(mosq.dat, vectorIndex(Pos, PoolSize, vector=Species, group=Zone))
     
VI(Pos ~ PoolSize | Zone / Species, mosq.dat)

## -----------------------------------------------------------------------------
with(mosq.dat, vectorIndex(Pos, PoolSize, vector=Species, trap.time = Nights, group=Zone))
     
VI(Pos ~ PoolSize | Zone / Species:Nights, mosq.dat)

## -----------------------------------------------------------------------------
pools.dat <- data.frame(Species=c("Cx. tarsalis","Cx. pipiens"),
                        Pos=c(1,1),
                        PoolSize=c(50,50),
                        NumPools=c(6,5))
pools.dat

## -----------------------------------------------------------------------------
traps.dat <- data.frame(Species = c("Cx. tarsalis","Cx. pipiens"),
                        Pos = c(NA,NA),
                        PoolSize=c(442, 233),
                        NumPools=c(1,1)) # note NumPools should be 1 for each entry
vi.dat <- rbind(pools.dat, traps.dat)
vi.dat

VI(Pos ~ PoolSize + n(NumPools) / Species, vi.dat, n.use.traps = FALSE, n.use.na = TRUE)
summary(VI(Pos ~ PoolSize + n(NumPools) / Species, vi.dat, n.use.traps = FALSE, n.use.na = TRUE))

## -----------------------------------------------------------------------------
# put 1s in for the pool data for later; use values for trap nights in application
vi.dat$TrapNights <- c(1,1,6,6) 
vi.dat

VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, 
                                     n.use.traps = FALSE, n.use.na = TRUE)
summary(VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, 
                                     n.use.traps = FALSE, n.use.na = TRUE))

## -----------------------------------------------------------------------------
VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, n.use.traps = FALSE, n.use.na = TRUE, pt.method="mir")
summary(VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, n.use.traps = FALSE, n.use.na = TRUE, pt.method="mir"))

## -----------------------------------------------------------------------------
# not trying to match the CDC guidelines report here, since in the example more individuals are
# included in the population size (mosquito density) measure
VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, 
                                     n.use.traps = TRUE, n.use.na = TRUE)
summary(VI(Pos ~ PoolSize + n(NumPools) / Species:TrapNights, vi.dat, 
                                     n.use.traps = TRUE, n.use.na = TRUE))

## -----------------------------------------------------------------------------
ipooledBin(Pos ~ PoolSize | Species, mosq.dat, sens=0.9, spec=0.95) 
summary(ipooledBin(Pos ~ PoolSize | Species, mosq.dat, sens=0.9, spec=0.95))

## -----------------------------------------------------------------------------
ipooledBin(Pos ~ PoolSize | Species, mosq.dat, sens=0.9, spec=0.95, pt.method="mle") 
summary(ipooledBin(Pos ~ PoolSize | Species, mosq.dat, sens=0.9, spec=0.95, pt.method="mle"))

